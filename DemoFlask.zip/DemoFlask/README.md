# Demo-Flask-SocketIO

Took some time to explore Flask-SocketIO from <a href="https://github.com/miguelgrinberg">Miguel Grinberg</a> 

Look for the blog post here: <a href="http://timmyreilly.azurewebsites.net/flask-socketio-and-more/">TimmyReilly.com</a>

In the process I've learned about some sweet stuff you can do with Javascript, Python, and Flask-SocketIO.


Flask is a <a href="http://flask.pocoo.org/">microframework<a>


Free <a href="http://www.microsoftvirtualacademy.com/training-courses/introduction-to-creating-websites-using-python-and-flask">MVA</a> on Flask if you want to learn more!


<strong>The five steps to this little demo project are as follows:</strong>

1. Install Flask-SocketIO into our Virtual Environment

2. Create our background thread

3. Have it emit the current state to our client

4. Call the background thread when our page render_template's

5. Have the Javascript Catch the emit and format our HTML.

Celebrate! Its Friday!

<span style="color: black;">Feel free to download it and start working with dynamic sites using SocketIO. Please let me know if you have any questions!
</span>

Woot!